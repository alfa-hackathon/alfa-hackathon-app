from typing import Dict, Any, List

from fastapi import FastAPI
from pydantic import BaseModel
from catboost import CatBoostClassifier, Pool
import pandas as pd

app = FastAPI()


class PredictRequest(BaseModel):
    features: Dict[str, Any]


MODEL_PATH = "catboost_model.cbm"

model = CatBoostClassifier()
model.load_model(MODEL_PATH)

FEATURE_NAMES: List[str] = list(model.feature_names_)  # порядок фич из модели

CAT_FEATURES = [
    "dt",
    "gender",
    "adminarea",
    "city_smart_name",
    "addrref",
]


@app.post("/predict")
def predict(request: PredictRequest):
    # 1. собираем строку строго по FEATURE_NAMES
    row: Dict[str, Any] = {}
    for name in FEATURE_NAMES:
        if name in request.features:
            row[name] = request.features[name]
        else:
            row[name] = 0

    df = pd.DataFrame([row])

    cat_cols = [c for c in CAT_FEATURES if c in df.columns]
    pool = Pool(df, cat_features=cat_cols)

    if hasattr(model, "predict_proba"):
        proba: List[List[float]] = model.predict_proba(pool)  # type: ignore
        p1 = float(proba[0][1])
    else:
        raw = float(model.predict(pool)[0])  # type: ignore
        p1 = max(0.0, min(1.0, raw))

    decision = "APPROVE" if p1 >= 0.5 else "REJECT"

    return {
        "approvalProbability": p1,
        "decision": decision,
    }
