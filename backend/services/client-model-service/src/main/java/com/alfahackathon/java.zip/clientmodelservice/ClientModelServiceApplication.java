package com.alfahackathon.clientmodelservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientModelServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientModelServiceApplication.class, args);
    }

}
