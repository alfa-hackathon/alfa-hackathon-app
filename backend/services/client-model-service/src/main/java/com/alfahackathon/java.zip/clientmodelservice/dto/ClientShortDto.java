package com.alfahackathon.clientmodelservice.dto;

public record ClientShortDto(
        Long id,
        String displayName
) {}
